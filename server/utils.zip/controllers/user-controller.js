let registerUser = async(req,res)=>{
    try {
        res.res("asfg sddg s ")
    } catch (error) {
        console.log(err)
    }
}

module.exports = {
    registerUser
}